package lab04;
import java.util.ArrayList;
import java.util.Scanner;

public class container2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the number of objects: ");
        int numObjects = input.nextInt();
        ArrayList<Integer> originalArray = new ArrayList<Integer>();

        System.out.println("Enter the weights: ");
        for (int i = 0; i < numObjects; i++) {
            originalArray.add(input.nextInt());
        }
        input.close();

        ArrayList<ArrayList<Integer>> containers = new ArrayList<ArrayList<Integer>>();

        for (Integer weight : originalArray) {
            boolean added = false;

            for (ArrayList<Integer> container : containers) {
                int sum = getSum(container);

                if (sum + weight <= 10) {
                    container.add(weight);
                    added = true;
                    break;
                }
            }

            if (!added) {
                ArrayList<Integer> newContainer = new ArrayList<Integer>();
                newContainer.add(weight);
                containers.add(newContainer);
            }
        }

        int containerNumber = 1;
        for (ArrayList<Integer> container : containers) {
            System.out.print("Container " + containerNumber + " contains objects with weight ");
            for (int i = 0; i < container.size(); i++) {
                System.out.print(container.get(i) + " ");
            }
            System.out.println();
            containerNumber++;
        }
    }

    private static int getSum(ArrayList<Integer> container) {
        int sum = 0;
        for (Integer weight : container) {
            sum += weight;
        }
        return sum;
    }
}

