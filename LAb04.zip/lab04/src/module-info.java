/**
 * 
 */
/**
 * 
 */
module lab04 {
}